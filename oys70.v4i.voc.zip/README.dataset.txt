# oys70 > 2024-02-15 4:09am
https://universe.roboflow.com/school-class-wndjm/oys70

Provided by a Roboflow user
License: CC BY 4.0

